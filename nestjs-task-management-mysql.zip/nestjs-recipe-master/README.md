# NestJS task management API

A small REST API with JWT authentication, user-scoped tasks, request validation,
and consistent HTTP error responses. It uses a local MySQL instance on port `3308`.

## Prerequisites

- Node.js 18 or later
- MySQL running at `localhost:3308`

## Setup

1. Create the database by running `database/init.sql` in MySQL.
2. Review `.env.stage.dev`. It assumes a local `root` user with an empty password;
   change `DB_USERNAME`, `DB_PASSWORD`, and `JWT_SECRET` before use if your local
   MySQL installation differs or you need a private development secret.
3. Install dependencies with `npm install`.
4. Start the API with `npm run start:dev`.

The server starts at `http://localhost:3000`. TypeORM creates the `user` and
`task` tables automatically in development (`synchronize: true`). Do not use
`synchronize: true` for a production database.

## API

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/auth/signup` | Create an account |
| POST | `/auth/signin` | Get a JWT access token |
| GET | `/tasks` | List your tasks; optional `status` and `search` query params |
| GET | `/tasks/:id` | Get one of your tasks |
| POST | `/tasks` | Create a task |
| PATCH | `/tasks/:id/status` | Set `OPEN`, `IN_PROGRESS`, or `DONE` |
| DELETE | `/tasks/:id` | Delete one of your tasks |

All `/tasks` endpoints require `Authorization: Bearer <accessToken>`.

Signup/signin body:

```json
{
  "username": "alice",
  "password": "StrongPass1!"
}
```

Create task body:

```json
{
  "title": "Write API docs",
  "description": "Document the task endpoints"
}
```

Errors use a predictable response shape with `statusCode`, `timestamp`, `path`,
and `message`. Validation rejects unknown request fields and invalid DTO values.
