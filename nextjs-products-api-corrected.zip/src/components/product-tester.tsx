"use client";

import { FormEvent, useEffect, useState } from "react";

type Product = { id: string; name: string; price: number };
type ApiResponse = { data?: Product | Product[]; error?: { message: string } };

const apiUrl = "/api/products-v2";

export function ProductTester() {
  const [products, setProducts] = useState<Product[]>([]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [selectedId, setSelectedId] = useState("");
  const [getProductId, setGetProductId] = useState("");
  const [updateName, setUpdateName] = useState("");
  const [updatePrice, setUpdatePrice] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [message, setMessage] = useState("Click Refresh to load products.");
  const [loading, setLoading] = useState(false);

  async function refreshProducts() {
    setLoading(true);
    const response = await fetch(apiUrl);
    const body = (await response.json()) as ApiResponse;
    setLoading(false);
    if (!response.ok) return setMessage(body.error?.message ?? "Could not load products.");
    const loadedProducts = body.data as Product[];
    setProducts(loadedProducts);
    if (!selectedId && loadedProducts[0]) setSelectedId(loadedProducts[0].id);
    if (!getProductId && loadedProducts[0]) setGetProductId(loadedProducts[0].id);
    setMessage(`GET succeeded: ${loadedProducts.length} product(s) loaded.`);
  }

  async function createProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, price })
    });
    const body = (await response.json()) as ApiResponse;
    setLoading(false);
    if (!response.ok) return setMessage(body.error?.message ?? "Product could not be created.");
    setName("");
    setPrice("");
    setMessage("POST succeeded: product created.");
    await refreshProducts();
  }

  async function getProduct() {
    if (!getProductId) return setMessage("Select a product first.");
    setLoading(true);
    const response = await fetch(`${apiUrl}/${getProductId}`);
    const body = (await response.json()) as ApiResponse;
    setLoading(false);
    if (!response.ok) return setMessage(body.error?.message ?? "Product could not be loaded.");
    setSelectedProduct(body.data as Product);
    setMessage("GET succeeded: one product loaded.");
  }

  async function updateProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    const response = await fetch(`${apiUrl}/${selectedId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: updateName, price: updatePrice })
    });
    const body = (await response.json()) as ApiResponse;
    setLoading(false);
    if (!response.ok) return setMessage(body.error?.message ?? "Product could not be updated.");
    setUpdateName("");
    setUpdatePrice("");
    setMessage("PUT succeeded: product updated.");
    await refreshProducts();
  }

  useEffect(() => { void refreshProducts(); }, []);

  return (
    <main style={{ fontFamily: "system-ui, sans-serif", maxWidth: 760, margin: "3rem auto", padding: "0 1rem" }}>
      <h1>Products API browser tester</h1>
      <p>Use this page to test your Next.js GET, POST, and PUT endpoints without Postman.</p>

      <section style={{ border: "1px solid #ddd", borderRadius: 8, padding: 20, marginBottom: 20 }}>
        <h2>Create product (POST)</h2>
        <form onSubmit={createProduct} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input aria-label="Product name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Product name" required />
          <input aria-label="Product price" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="Price" type="number" min="0.01" step="0.01" required />
          <button disabled={loading} type="submit">Create product</button>
        </form>
      </section>

      <section style={{ border: "1px solid #ddd", borderRadius: 8, padding: 20, marginBottom: 20 }}>
        <h2>Update product (PUT)</h2>
        <form onSubmit={updateProduct} style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select aria-label="Product to update" value={selectedId} onChange={(event) => setSelectedId(event.target.value)} required>
            <option value="">Select a product</option>
            {products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}
          </select>
          <input aria-label="Updated product name" value={updateName} onChange={(event) => setUpdateName(event.target.value)} placeholder="Updated name" required />
          <input aria-label="Updated product price" value={updatePrice} onChange={(event) => setUpdatePrice(event.target.value)} placeholder="Updated price" type="number" min="0.01" step="0.01" required />
          <button disabled={loading} type="submit">Update product</button>
        </form>
      </section>

      <section style={{ border: "1px solid #ddd", borderRadius: 8, padding: 20, marginBottom: 20 }}>
        <h2>Get one product (GET)</h2>
        <p>Select the product you want to retrieve.</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select aria-label="Product to get" value={getProductId} onChange={(event) => setGetProductId(event.target.value)}>
            <option value="">Select a product</option>
            {products.map((product) => <option key={product.id} value={product.id}>{product.name}</option>)}
          </select>
          <button disabled={loading || !getProductId} onClick={() => void getProduct()}>Get selected product</button>
        </div>
        {selectedProduct && (
          <pre style={{ background: "#f5f5f5", padding: 12, overflow: "auto" }}>
            {JSON.stringify(selectedProduct, null, 2)}
          </pre>
        )}
      </section>

      <section style={{ border: "1px solid #ddd", borderRadius: 8, padding: 20 }}>
        <h2>Products (GET)</h2>
        <button disabled={loading} onClick={() => void refreshProducts()}>Refresh products</button>
        <p aria-live="polite"><strong>{message}</strong></p>
        {products.length === 0 ? <p>No products yet.</p> : (
          <ul>
            {products.map((product) => (
              <li key={product.id} style={{ marginBottom: 10 }}>
                {product.name} — ₹{product.price}
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
