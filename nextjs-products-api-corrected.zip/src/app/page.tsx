import { ProductTester } from "@/components/product-tester";

export default function Home() {
  return <ProductTester />;
}
