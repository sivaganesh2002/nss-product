import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Layered Next.js API",
  description: "A module, controller, service, and DTO example"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
