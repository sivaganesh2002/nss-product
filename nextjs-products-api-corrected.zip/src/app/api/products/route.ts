import { productController } from "@/modules/products/product.module";

export const GET = productController.list;
export const POST = productController.create;
