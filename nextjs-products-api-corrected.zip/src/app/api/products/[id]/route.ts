import { productController } from "@/modules/products/product.module";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(_: Request, { params }: RouteContext) {
  return productController.get((await params).id);
}

export async function PUT(request: Request, { params }: RouteContext) {
  return productController.update(request, (await params).id);
}

export async function DELETE(_: Request, { params }: RouteContext) {
  return productController.remove((await params).id);
}
