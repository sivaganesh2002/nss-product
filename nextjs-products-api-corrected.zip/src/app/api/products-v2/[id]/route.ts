import { productController } from "@/modules/products/product.module";

type RouteContext = { params: Promise<{ id: string }> };

// GET /api/products-v2/:id - get one product
export async function GET(_: Request, { params }: RouteContext) {
  return productController.get((await params).id);
}

// PUT /api/products-v2/:id - update a product
export async function PUT(request: Request, { params }: RouteContext) {
  return productController.update(request, (await params).id);
}
