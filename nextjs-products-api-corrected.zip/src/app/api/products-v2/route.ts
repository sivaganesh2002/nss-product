import { productController } from "@/modules/products/product.module";

// GET /api/products-v2 - list all products
export const GET = productController.list;

// POST /api/products-v2 - create a product
export const POST = productController.create;
