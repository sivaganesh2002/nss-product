import { errorResponse } from "@/lib/api-response";
import { createProductSchema, productIdSchema, updateProductSchema } from "./dto/product.dto";
import { ProductService } from "./product.service";

export class ProductController {
  constructor(private readonly service: ProductService) {}

  list = async () => {
    try {
      return Response.json({ data: this.service.findAll() });
    } catch (error) { return errorResponse(error); }
  };

  get = async (id: string) => {
    try {
      const { id: validId } = productIdSchema.parse({ id });
      return Response.json({ data: this.service.findById(validId) });
    } catch (error) { return errorResponse(error); }
  };

  create = async (request: Request) => {
    try {
      const dto = createProductSchema.parse(await request.json());
      return Response.json({ data: this.service.create(dto) }, { status: 201 });
    } catch (error) { return errorResponse(error); }
  };

  update = async (request: Request, id: string) => {
    try {
      const { id: validId } = productIdSchema.parse({ id });
      const dto = updateProductSchema.parse(await request.json());
      return Response.json({ data: this.service.update(validId, dto) });
    } catch (error) { return errorResponse(error); }
  };

  remove = async (id: string) => {
    try {
      const { id: validId } = productIdSchema.parse({ id });
      this.service.remove(validId);
      return new Response(null, { status: 204 });
    } catch (error) { return errorResponse(error); }
  };
}
