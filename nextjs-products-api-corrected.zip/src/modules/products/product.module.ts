import { ProductController } from "./product.controller";
import { ProductService } from "./product.service";

const productService = new ProductService();
export const productController = new ProductController(productService);
