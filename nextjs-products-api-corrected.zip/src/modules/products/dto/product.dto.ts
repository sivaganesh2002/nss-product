import { z } from "zod";

export const productIdSchema = z.object({ id: z.uuid("Product id must be a valid UUID") });

export const createProductSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters").max(100),
  price: z.coerce.number().positive("Price must be greater than zero").max(1_000_000),
  description: z.string().trim().min(1).max(500).optional()
});

export const updateProductSchema = createProductSchema.partial().refine(
  (value) => Object.keys(value).length > 0,
  "Provide at least one field to update"
);

export type CreateProductDto = z.infer<typeof createProductSchema>;
export type UpdateProductDto = z.infer<typeof updateProductSchema>;
