import { randomUUID } from "crypto";
import { notFound } from "@/lib/app-error";
import type { CreateProductDto, UpdateProductDto } from "./dto/product.dto";
import type { Product } from "./product.types";

// Route handlers are bundled separately by Next.js. Keeping the demo store on
// globalThis makes it available to both `/api/products` and `/api/products/[id]`.
// Replace this function with a repository backed by a database in production.
const productStoreHost = globalThis as typeof globalThis & {
  __layeredProductsStore?: Map<string, Product>;
};

function getProductStore(): Map<string, Product> {
  productStoreHost.__layeredProductsStore ??= new Map<string, Product>();
  return productStoreHost.__layeredProductsStore;
}

export class ProductService {
  private readonly products = getProductStore();

  findAll(): Product[] {
    return [...this.products.values()];
  }

  findById(id: string): Product {
    const product = this.products.get(id);
    if (!product) throw notFound("Product");
    return product;
  }

  create(dto: CreateProductDto): Product {
    const now = new Date().toISOString();
    const product: Product = { id: randomUUID(), ...dto, createdAt: now, updatedAt: now };
    this.products.set(product.id, product);
    return product;
  }

  update(id: string, dto: UpdateProductDto): Product {
    const existing = this.findById(id);
    const updated = { ...existing, ...dto, updatedAt: new Date().toISOString() };
    this.products.set(id, updated);
    return updated;
  }

  remove(id: string): void {
    this.findById(id);
    this.products.delete(id);
  }
}
