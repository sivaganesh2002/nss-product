# Layered Next.js Products API

A simple Next.js App Router API with clear layers:

```
Route -> Controller -> Service -> in-memory data store
                 ^
                DTOs (Zod validation)
```

## Run it

```bash
npm install
npm run dev
```

The API is served at `http://localhost:3000/api/products`.

`/api/products-v2` is a separate corrected example containing only GET, POST, and PUT routes. Its Postman collection is `postman/products-v2-get-post-put.postman_collection.json`.

## Test in Postman

1. Import `postman/products-api.postman_collection.json`.
2. Run **Create product** first. Its test script saves the returned id as `productId`.
3. Run the list, get, update, and delete requests.
4. Run the two error examples to inspect the standardized response shape.

## Endpoints

| Method | Route | Result |
| --- | --- | --- |
| GET | `/api/products` | List products |
| POST | `/api/products` | Create a product |
| GET | `/api/products/:id` | Get one product |
| PUT | `/api/products/:id` | Update one product |
| DELETE | `/api/products/:id` | Delete one product |

Invalid input returns `400 VALIDATION_ERROR`; missing products return `404 NOT_FOUND`; unhandled failures return `500 INTERNAL_SERVER_ERROR`.

Products are kept in memory, so restarting the development server clears them.
